package fr.upsaclay.bibs.fieldsystem.view;

import fr.upsaclay.bibs.fieldsystem.sheepfield.Field;

public interface FieldView {
	
	public void initialize(Field field);
	
	public void update(Field field);

}
