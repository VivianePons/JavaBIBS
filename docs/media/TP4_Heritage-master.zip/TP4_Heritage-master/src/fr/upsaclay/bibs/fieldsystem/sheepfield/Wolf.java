package fr.upsaclay.bibs.fieldsystem.sheepfield;

public class Wolf {
	
	/** Static parameters of the class Wolf
	 * These are static parameters defining the behavior of
	 * the Wolf elements
	 */
	private static int defaultLifeSpan = 10;
	private static int defaultWeakLevel = 2;
	private static int defaultIncreasePerEat = 4;
	private static int defaultSpeed = 1;
	private static double defaultReproductionProba = 0.1;
	
	public Wolf() {
		throw new UnsupportedOperationException("Not implemented yet");
	}
	

	public static int getDefaultLifeSpan() {
		return Wolf.defaultLifeSpan;
	}
	
	public static void setDefaultLifeSpan(int defaultLifeSpan) {
		Wolf.defaultLifeSpan = defaultLifeSpan;
	}
	
	public static int getDefaultWeakLevel() {
		return defaultWeakLevel;
	}

	public static void setDefaultWeakLevel(int defaultWeakLevel) {
		Wolf.defaultWeakLevel = defaultWeakLevel;
	}
	
	public static int getDefaultIncreasePerEat() {
		return Wolf.defaultIncreasePerEat;
	}

	public static void setDefaultIncreasePerEat(int defaultIncreasePerEat) {
		Wolf.defaultIncreasePerEat = defaultIncreasePerEat;
	}
	
	public static int getDefaultSpeed() {
		return Wolf.defaultSpeed;
	}

	public static void setDefaultSpeed(int defaultSpeed) {
		Wolf.defaultSpeed = defaultSpeed;
	}
	
	public static double getDefaultReproductionProba() {
		return Wolf.defaultReproductionProba;
	}

	public static void setDefaultReproductionProba(double defaultReproductionProba) {
		if(defaultReproductionProba > 1 || defaultReproductionProba < 0) {
			throw new IllegalArgumentException();
		}
		Wolf.defaultReproductionProba = defaultReproductionProba;
	}
	

}
