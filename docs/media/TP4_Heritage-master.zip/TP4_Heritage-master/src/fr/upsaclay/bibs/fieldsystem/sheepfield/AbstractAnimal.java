package fr.upsaclay.bibs.fieldsystem.sheepfield;

public abstract class AbstractAnimal extends AbstractFieldElement {
	

	private boolean dead = false;
	
	public AbstractAnimal(FieldElementType type) {
		super(type);
		activate();
	}
	
	/**
	 * Return the life span level where the animal is considered weak
	 * @return the level as an int
	 */
	public abstract int getWeakLevel();
	
	/**
	 * Return the life span increase when the animal eats
	 * @return the increase as an int
	 */
	public abstract int getIncreasePerEat();
	
	/**
	 * Return the number of steps the animal can make in one round
	 * @return the speed as an int
	 */
	public abstract int getSpeed();
	
	/**
	 * Return the probability to reproduce at each round
	 * @return a double between 0 and 1
	 */
	public abstract double getReproductionProba();
	
	/**
	 * Create a new instace
	 * @return a new instance of animal
	 */
	public abstract FieldElement newInstance();
	
	@Override
	public boolean isActive() {
		throw new UnsupportedOperationException("Not implemented yet");
	}
	
	@Override
	public boolean isDead() {
		throw new UnsupportedOperationException("Not implemented yet");
	}
	
	@Override
	public boolean isWeak() {
		throw new UnsupportedOperationException("Not implemented yet");
	}
	
	@Override
	public boolean canEat() {
		throw new UnsupportedOperationException("Not implemented yet");
	}
	
	/**
	 * Return if the animal can eat another element
	 * this is directly computed using the type level 
	 * in the food chain
	 * @param the type to be eaten
	 * @return true if the eaten type is extactly one level below the level of the current type
	 *         (as an example the wolf can eat the sheep. The sheep can eat the grass. But the
	 *         wolf cannot eat the grass)
	 */
	@Override
	public boolean canEat(FieldElementType type) {
		throw new UnsupportedOperationException("Not implemented yet");
	}
	
	@Override
	public void eaten() {
		throw new UnsupportedOperationException("Not implemented yet");
	}
	
	@Override
	public void eat(FieldElement element) {
		throw new UnsupportedOperationException("Not implemented yet");
	}
	
	@Override
	public boolean canMove() {
		throw new UnsupportedOperationException("Not implemented yet");
	}
	
	@Override
	public FieldMove nextMove(Position position, Position target) {
		if(position.equals(target)) {
			return new FieldMove(this, position, position);
		}
		throw new UnsupportedOperationException("Not implemented yet");
	}
	
	@Override
	protected void actionZeroLifeSpan() {
		throw new UnsupportedOperationException("Not implemented yet");
	}
	
	@Override
	public FieldElement conditionnalReproduce() {
		throw new UnsupportedOperationException("Not implemented yet");
		
	}

}
