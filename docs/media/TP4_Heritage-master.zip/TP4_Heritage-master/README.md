# TP Java Héritage

Ce repo contient le code nécessaire à la réalisation d'un TP de Java d'implantation d'un système dynamique.
